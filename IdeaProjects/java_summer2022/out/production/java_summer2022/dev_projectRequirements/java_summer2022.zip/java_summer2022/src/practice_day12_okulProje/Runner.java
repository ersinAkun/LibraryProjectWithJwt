package practice_day12_okulProje;

import static practice_day12_okulProje.Islemler.girisPaneli;

public class Runner {
    public static void main(String[] args) {
        girisPaneli();

    }
}
