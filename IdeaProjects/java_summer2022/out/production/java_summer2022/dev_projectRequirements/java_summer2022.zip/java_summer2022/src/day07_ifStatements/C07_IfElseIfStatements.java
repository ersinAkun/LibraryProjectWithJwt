package day07_ifStatements;

import java.util.Scanner;

public class C07_IfElseIfStatements {
    public static <Scaner> void main(String[] args) {

        //bir önceki soruda kull negatif değer girerse uyaralım

        Scanner scan = new Scanner(System.in);



    }
}
