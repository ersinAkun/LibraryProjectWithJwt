package day04_dataCasting;

public class C02_DataCasting {
    public static void main(String[] args) {

        int sayi1 = 23;
        int sayi2 = 5;


        System.out.println(sayi1/sayi2);

        double sayi3 = 5;
        System.out.println(sayi1/sayi3);



    }
}
