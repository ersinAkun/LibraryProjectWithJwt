package practice_day12_okulProje;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Islemler {

    static List<Kisi> ogretmenList = new ArrayList<>();
    static List<Kisi> ogrenciList = new ArrayList<>();
    static Scanner scan = new Scanner(System.in);
    static String kisiTuru;

    public static void girisPaneli() {

        System.out.println("====================================\n" +
                "ÖĞRENCİ VE ÖĞRETMEN YÖNETİM PANELİ\n" +
                "====================================\n" +
                "1- ÖĞRENCİ İŞLEMLERİ\n" +
                "2- ÖĞRETMEN İŞLEMLERİ\n" +
                "Q- ÇIKIŞ");

        String secim = scan.next().toUpperCase();
        switch (secim) {
            case "1":
                kisiTuru = "OGRENCI";
                islemMenusu();
                break;

            case "2":
                kisiTuru = "OGRETMEN";
                islemMenusu();
                break;
            case "Q":

                break;
            default:
                System.out.println("Hatali griis yaptiniz tekrar deneyin");
                girisPaneli();
                break;
        }


    }

    private static void islemMenusu() {
        System.out.println("Sectigin kisi turu " + kisiTuru + " lutfen asagidaki islemleri seciniz");

        System.out.println("============= İŞLEMLER =============\n" +
                "         1-EKLEME\n" +
                "         2-ARAMA\n" +
                "         3-LİSTELEME\n" +
                "         4-SİLME\n" +
                "         5-ANA MENÜ\n" +
                "         0-ÇIKIŞ");

        System.out.println("Islem tercihinizi giriniz : ");
        int secilenIslem = scan.nextInt();

        switch (secilenIslem) {
            case 1:
                ekle();
                islemMenusu();
                break;
            case 2:
                arama();
                islemMenusu();
                break;
            case 3:
                listele();
                islemMenusu();
                break;
            case 4:

                islemMenusu();
                break;
            case 5:
                girisPaneli();  // ana menu
                break;
            case 0:
                //cikis();
                break;
            default:
                System.out.println("Yanlis giris yaptiniz tekrar giris yapin");
                islemMenusu();
                break;
        }

    }

    private static void listele() {






    }

    private static void arama() {
        System.out.println(" *** " + kisiTuru + " Arama sayfasina hosgeldiniz");
        System.out.println("isim soyisim giriniz");
        String adSoyad = scan.nextLine();
        scan.nextLine();
        System.out.println("Kimlik no giriniz");
        String kimlikNo = scan.next();
        System.out.println(ogrenciList+"*****************");

        if (kisiTuru.equals("OGRENCI")) {
            if (ogrenciList.contains(adSoyad)) {

                Kisi ogrenci = new Ogrenci(adSoyad, kimlikNo);
                System.out.println(ogrenci.getAdSoyad()+" isimli ogrenci kayitli ogrencimizdir");
            }else     System.out.println(adSoyad+" isimli ogrenci kayitli degil");



            //System.out.println("Sinifinizi Giriniz");
            // String siniifNo = scan.nextLine();

            //Ogrenci ogrenci = new Ogrenci(adSoyad,kimlikNo,yas,ogrenciNo,siniifNo);
            // ogrenciList.add(ogrenci);
            // System.out.println(ogrenciList);

        } else {  // OGRETMEN SE
            System.out.println("Bolumunuzu giriniz");
            String bolum = scan.nextLine();
            scan.nextLine();
            System.out.println("Sicil no giriniz");
            String sicilNo = scan.nextLine();

            //  Ogretmen ogretmen = new Ogretmen(adSoyad, kimlikNo, yas, bolum, sicilNo);
            //   ogretmenList.add(ogretmen);
            System.out.println(ogretmenList);

        }


    }

    private static void ekle() {   //bu method hem ogrenci hemde ogrenci eklemek icin tasarlandi
        System.out.println(" *** " + kisiTuru + " ekleme sayfasina hosgeldiniz");
        System.out.println("isim soyisim giriniz");
        String adSoyad = scan.nextLine();
        scan.nextLine();
        System.out.println("Kimlik no giriniz");
        String kimlikNo = scan.next();

        System.out.println("Yasinizi giriniz");
        int yas = scan.nextInt();

        if (kisiTuru.equals("OGRENCI")) {
            System.out.println("Ogrenci No Giriniz");
            String ogrenciNo = scan.next();
            scan.nextLine();
            System.out.println("Sinifinizi Giriniz");
            String siniifNo = scan.nextLine();

            Ogrenci ogrenci = new Ogrenci(adSoyad, kimlikNo, yas, ogrenciNo, siniifNo);
            ogrenciList.add(ogrenci);
            System.out.println(ogrenciList);

        } else {  // OGRETMEN SE
            System.out.println("Bolumunuzu giriniz");
            String bolum = scan.nextLine();
            scan.nextLine();
            System.out.println("Sicil no giriniz");
            String sicilNo = scan.nextLine();

            Ogretmen ogretmen = new Ogretmen(adSoyad, kimlikNo, yas, bolum, sicilNo);
            ogretmenList.add(ogretmen);
            System.out.println(ogretmenList);

        }


    }


}
