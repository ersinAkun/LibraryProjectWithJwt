package day05_matematikselIslemler;

public class C04_WrapperClass {
    public static void main(String[] args) {

        String str = "Java çok güzel";
        str.toUpperCase();

        int sayi = 10;
        // primitive data türlerinin yanında metotlar olmaz

        Integer sayi2 = 10;

        sayi2.byteValue();

    }
}
