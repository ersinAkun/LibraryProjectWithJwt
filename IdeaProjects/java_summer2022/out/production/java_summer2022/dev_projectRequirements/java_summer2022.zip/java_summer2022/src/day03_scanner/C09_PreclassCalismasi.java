package day03_scanner;


import java.util.Scanner;

public class C09_PreclassCalismasi {
    public static void main(String[] args) {
    /*
        Scanner scan = new Scanner(System.in);
        System.out.println("Bir sayı giriniz ardından enter a basıp \nbir sayı daha giriniz");
        int sayi1 = scan.nextInt();
        int sayi2 = scan.nextInt();

        System.out.println("girdiğiniz sayıların toplamı  :  "+(sayi1+sayi2) );
        System.out.println("girdiğiniz sayıların farkı  :  "+(sayi1-sayi2));
        System.out.println("girdiğiniz sayıların çarpımı  :  "+(sayi1*sayi2));
      */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("Karenin Kenar Uzunluğunu Giriniz");
        double kareKenarı = scan.nextDouble();
        System.out.println("Karenin Çevre uzunluğu : "+(kareKenarı*4)+"Karenin Alanı :   "+(kareKenarı*kareKenarı));
        */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("Çemberin Yarıçapını Giriniz");
        float yariCap = scan.nextFloat();
        System.out.println("Çemberin Çeveresi :  "+(yariCap*2*3)+"Dairenin Alanni  : "+(3*yariCap*yariCap));
        */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("Sırasıyla prizmanın kısa kenarını uzun kenarını ve yüksekliğini giriniz \nher girişten sonra enter a basınız");
        double kisaKenar =scan.nextDouble();
        double uzunKenar =scan.nextDouble();
        double yükseklik =scan.nextDouble();
        System.out.println("Pirizmanın Hacmi  :  "+(kisaKenar*uzunKenar*yükseklik));
        */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("isminizi yazınız"+"  sonra  "+"soyisminizi yazınız");

        String isim = scan.next();
        String soyisim = scan.next();
        System.out.println("isminiz  :  "+isim+ "      "+"soyisminiz  :  "+soyisim);
        System.out.println("Kursumuza katılımınız alınmıştır, teşekkür ederiz");
        */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("adınızı ve soyadınızı giriniz");
        String isim = scan.next();
        String soyisim = scan.next();
        System.out.println("isim-soyisim  : "+isim+" "+soyisim);
        */
        /*
        Scanner scan = new Scanner(System.in);
        System.out.println("ismnizi yazınız");
        char isim = scan.next().charAt(0);
        System.out.println(isim);
        */
    }
}
