package day37_overriding;

public class C01_Overloading {
    public static void main(String[] args) {

       /*
       Bir class ta ayni isimde ve ayni signature e sahip iki method olmaz
        Ayni class ta Ayni isimde birden faZla methodd olustturmak istersek
        mutlaka signature 'i degistirmeliyiz

        Farkli classlarda ayni isim ve signatur/a sahip iki method olabilir mi ?
        */

    }

    void ekleme (){

    }
    void ekleme(int sayi){

    }
    void ekleme(String str){

    }
    void ekleme(String str, int sayi ){

    }
    void ekleme(int sayi, String str){

    }


}
