package dev_projectRequirements;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScannerSecim {


    public static void secim() {
        System.out.println("=================================\n");


       //UrunSec.urunSec();



    }
}
