package day03_scanner;
public class C01_AsciiTable {

    public static void main(String[] args) {
        String opt = "true";
        switch (opt) {
            case "true":
                System.out.println("true");
                break;
            default:
                System.out.println("****");
        }
        System.out.println("done");
        System.out.println(2+3<5);
    }
}
