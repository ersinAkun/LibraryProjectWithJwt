package practice_day09_practice;

public class Batch {

    String str1 = "Batch 81 82 83 Constructor i anladi";

    String str2 = "Batch 81 82 83 Constructor i anlamadi";

    String str3 = "Batch 81 82 83 Constructor i anladi fakat oturmadi";

    String str4 = "Batch 81 82 83 Constructor i zamanla ANLAYACAKSINIZ";

    public void batch(){
        System.out.println("str4 = " + str4);
    }

}
