package day37_overriding;

public class C02_Overriding {

    public static void main(String[] args) {
        /*
        Farkli class'larda ayni isim ve signature'da
        method'lar olusturabiliriz
        cunku herbir class kendi icinde calisir
         */
    }
    void ekleme (){

    }
    void ekleme(int sayi){

    }
    void ekleme(String str){

    }

}
