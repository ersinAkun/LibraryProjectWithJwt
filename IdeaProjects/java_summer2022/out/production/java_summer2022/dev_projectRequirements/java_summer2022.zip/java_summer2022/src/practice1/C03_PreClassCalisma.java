package practice1;

public class C03_PreClassCalisma {
    public static void main(String[] args) {


        System.out.println(Integer.MAX_VALUE);
        System.out.println(Integer.MIN_VALUE);





/*
        Scanner scan = new Scanner(System.in);
        System.out.println("Bir tamsayı giriniz");
        int sayi = scan.nextInt();
        if (sayi%2 ==0){
            System.out.println("sayı çift sayıdır");
        }else{
            System.out.println("sayımız çift değildir");
        }*/


/*
        Scanner scan = new Scanner((System.in));
        System.out.println("lütfen bir gün ismi giriniz");
        String girilenGun = scan.next().toLowerCase();

        if (girilenGun.equals("pazar") || (girilenGun.equals("cumartesi"))) {
            System.out.println("girilen gün haftasonu");
        }
        if (girilenGun.equals("pazartesi")||(girilenGun.equals("salı") ||(girilenGun.equals("çarşamba")|| girilenGun.equals("perşembe")||(girilenGun.equals("cuma"))))){
            System.out.println("girilen gün hafta içi");
        }else {
            System.out.println("geçerli bir gün ismi giriniz");
        }*/
/*
        Scanner scan = new Scanner(System.in);
        System.out.println("lütfen bir karakter giriniz");
        char chr = scan.next().charAt(0);

        if ( (chr >='a' && chr <='z') || (chr >='A' && chr <='Z')){
            System.out.println("girilen karakter  : " + chr);
        }else {
            System.out.println("lütfen doğru bir karakter giriniz");
        }*/
/*
        Scanner scan = new Scanner(System.in);
        System.out.println("lütfen yaşınızı giriniz");
        int yas = scan.nextInt();

        if (yas<65){
            System.out.println("emekli olamazsın  " +(65-yas) +" yıl daha çalışmalısın");
        }else {
            System.out.println("emekli olabilirsin");
        }
*/

        }



    }

