package day14_methodCreation;

public class C06_MethdoCreation {
    public static void main(String[] args) {

        System.out.println(C05_MethodCreationReturn.sehirAl());
    }
}
