package day06_concatenation;

public class C05_PrimitiveDataTypes {
    public static void main(String[] args) {

        float laptopFiyat = 999.99f;
        double kilometre = 34.56;
        char seviye = 'A';
        boolean dogruMu = true;

        System.out.println("laptopFiyat = " + laptopFiyat);
        System.out.println("kilometre = " + kilometre);
        System.out.println("seviye = " + seviye);
        System.out.println("dogruMu = " + dogruMu);



    }
}
