package day07_ifStatements;

public class C02_IfStatement {
    public static void main(String[] args) {

        int sayi = -23;

        if(sayi>0){
            System.out.println("sayi pozitif");
        }
        if (sayi%2==0){
            System.out.println("sayi çift");
        }
        if (sayi%5==0){
            System.out.println("sayi 5 in tam katı");
        }

  /* basit if cümleleri kodun diğer parçalarından bağımsızdır sadece 1şaret
  kontrol eder şart sağlanıyorsa if body çalışır yoksa çalışmaz
  birden fazla basit if cümlesi varsa girilen şarta bağlı olarak tümünde
  if body si çalışabilir kısmen if body leri çalışabilir
  veya hiçbir if body si çalışmayabilir
   */

    }
}
