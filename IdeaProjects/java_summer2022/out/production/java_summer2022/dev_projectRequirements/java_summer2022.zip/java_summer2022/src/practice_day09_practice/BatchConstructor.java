package practice_day09_practice;

public class BatchConstructor {

    public static void main(String[] args) {


        Batch batch = new Batch();

        System.out.println("batch.str1 = " + batch.str1);

        batch.batch();

    }




}
