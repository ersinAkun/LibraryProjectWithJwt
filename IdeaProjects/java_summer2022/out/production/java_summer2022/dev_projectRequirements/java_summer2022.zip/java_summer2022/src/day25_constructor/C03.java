package day25_constructor;

public class C03 {
    /*
    proje olusturulurken bazi class lar run etmek icin degil
    variable ve method olusturup bunlari baska class lardan kullanmak
    icin olusturulur
     */
    /*
    Default constructor parametresizdir
    goremesek bile ihtiyac oldugunda calisir

    Class icerisinde oarametreli yada parametresiz herhangi bir
    constructor olusturursak Java default constructor u siler.
     */
    C03(){

    }
    /*
    olusturdugumuz parametresiz bu constructor Default constructor
    ile 1'e1 aynidir
    ama biz olusturdgumuz icin buna default constructor demeyiz
    parametresiz constructor deriz.
     */

    String isim = "Etka";

    public void method01(){

        System.out.println("C03 method calisti");
    }

}
