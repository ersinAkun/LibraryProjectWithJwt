package day19_scope;

public class C04_Scope {







    public static void main(String[] args) {

    }
}
