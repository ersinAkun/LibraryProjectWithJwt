package day25_constructor;

public class C01 {
    /*
    java oop konsept kullandigi icin olusturulan her bir class in ihtiyac
    oldugunda obje uretilmesine uygun dizayn etmistir Ama her class tan obje
    uretilmeyebilir
    Bunun icin Java ihtiyac halinde kullanilmasi icin her class ta default bir
    constructor koymustur
    Bu default constructor Class tan obje olusturuldugunda otomatik olarak calisir

     ornegin
     */

    int sayi;
    public void deneme(){
        System.out.println("C01'den deneme method calisir");
    }
}
