package dev_projectRequirements;

public class Planning {
 /*
    1) urunler String) ve urunfiyatlari double icin ayri list olusturun
      class level da tanimlayiniz static
      main method disinda ama main methoddan call yapcaz

      liste alinan urunleri user a gostermek icin method create edelim
      method--> public static void ürünleriListele(){for i ,
     printl(i+\t +urun\t+fiyat} pmsiz

   2)scannner class dan obj create ediniz ürünleriListele() methodu call ediniz
     kullanicinin ekrania gosterelim.

   3) nasil secim alirim
     urunNo giricek kulanici ve urunMiktari giricek yeni variable larimi oldu
     urunNo=int , urunMiktari=double
     fiyat uyarisi veren bir code yaziniz yani 1000 tl yi asti sepet gibi

   4)sepetUrunler list(String), sepetKg(double), sepetFiyat(double)
     method-->public static void sepeteEkle(int urunNo,double urunMiktari){
       }
     ? devam mi odemem mi
     5) sepetiYazdir methodun create ediniz
     method--> public static double(toplamFiyat) sepeteYazdir(){
     println(urunler fiyat kg )
     }?6) burdan onra ne yapmaliyim
     String tipinde secim aliniz e/h olarak
     cevap evet ise== do kismi
     cevap hayir ise ==while sarti calisisin odeme talep edilsin
     7)odeme de neler yapabiliriz
     coin kargo (nakit) kartla veresiye
     method--> public static void odeme(double toplamFiyat){println()}
     */
}
