package day06_concatenation;

public class C03_Practise_PrinLPrintln {
    public static void main(String[] args) {
//println
        System.out.println("****println****");
        System.out.println("welcome");
        System.out.println("java");
        System.out.println("practice1");
        System.out.println("");
//print
        System.out.println("***print***");
        System.out.print("welcome");
        System.out.print(" java");
        System.out.print(" class");
    }
}
