package day02_variables;

public class C01_Variables {
    public static void main(String[] args) {
        int             not                =                  60                          ;
     // data türü  #  variable ismi  # assignment sign  # variable değeri     #   işlem bitti işareti


        int not2 = 70;
    // variable    değer  => java önce değeri hesaplar sonra assign işlemini yapar

    // not2 yi 80 yapalım
        not2 = 90;

        int ortalama= (not+not2)/2;
        System.out.println("ortalamamız  :  "+ortalama);



    }
}
