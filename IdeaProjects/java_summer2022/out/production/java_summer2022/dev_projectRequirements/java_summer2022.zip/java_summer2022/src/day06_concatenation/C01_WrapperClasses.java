package day06_concatenation;

public class C01_WrapperClasses {
    public static void main(String[] args) {

        String str = "java ile hayat ne güzel";
        System.out.println(str.toUpperCase());

        boolean buGuzelMi = true;


    }
}
