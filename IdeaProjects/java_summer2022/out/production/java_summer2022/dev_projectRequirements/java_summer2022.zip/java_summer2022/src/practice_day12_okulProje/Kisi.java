package practice_day12_okulProje;

public class Kisi {

    private String adSoyad;
    private String kimlikNO;
    private int yas;    // herkesin ortak ozelligi

    public Kisi(){

}
    public Kisi(String adSoyad, String kimlikNO) {
        this.adSoyad = adSoyad;
        this.kimlikNO=kimlikNO;
    }
    public Kisi(String adSoyad, String kimlikNO, int yas) {
        this.adSoyad = adSoyad;
        this.kimlikNO = kimlikNO;
        this.yas = yas;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getKimlikNO() {
        return kimlikNO;
    }

    public void setKimlikNO(String kimlikNO) {
        this.kimlikNO = kimlikNO;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {    // yas kontrolu yapiniz
        this.yas = yas;
    }

    @Override
    public String toString() {
        return "\nKisi" +
                "\nadSoyad : " + adSoyad +
                "\n kimlikNO : " + kimlikNO +
                "\n yas : " + yas ;

    }
}
