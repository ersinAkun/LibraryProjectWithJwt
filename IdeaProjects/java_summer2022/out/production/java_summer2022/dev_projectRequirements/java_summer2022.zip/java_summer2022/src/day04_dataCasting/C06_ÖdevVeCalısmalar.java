package day04_dataCasting;

public class C06_ÖdevVeCalısmalar {
    public static void main(String[] args) {
/*
        byte yas = 85;
        short benYas = yas;
        int ourYas = benYas;
        float unYas = ourYas;
        double mmYas = unYas;

        System.out.println("yas  :"+yas+"   benYas  : "+ benYas+"    ourYas  : "+ ourYas+"    unYas"+unYas+"    mmYas  : "+mmYas);
*/
        /*
        int sayihtc = 100;
        short sayihtc1 = (short)sayihtc;
        byte sayihtc2 = (byte)sayihtc1;
        char sayihtc3 = (char)sayihtc2;
        System.out.println(sayihtc+"..."+sayihtc1+"..."+sayihtc2+"..."+sayihtc3);
        */
        /*
        float veriOrani = 98f;
        System.out.println(veriOrani);
        */
/*
        double sayimiz = 255.36;
        System.out.println(sayimiz);
        int mySayimiz = (int)sayimiz;
        System.out.println(mySayimiz);
        byte mySayimiz1 = (byte)mySayimiz;
        System.out.println(mySayimiz1);
*/      /*
        int kusSayisi = 1000;
        int aliciSayisi = 20;
        System.out.println("gereken fatura miktarı  :"+kusSayisi/aliciSayisi);
*/   /*
        double counted = 125.987;
        int tax = 50;
        System.out.println(tax/counted);   */
/*
        char ad = 'é';
        byte ada = 127;
        short adb = 32000;
        int adc = 5000250;
        long add = 10000000;
        float ade = 15.150f;
        double adf = 32.365200025;
        System.out.println((ad+adb)+(add/ada)+(ade*adf));
*/







    }
}
