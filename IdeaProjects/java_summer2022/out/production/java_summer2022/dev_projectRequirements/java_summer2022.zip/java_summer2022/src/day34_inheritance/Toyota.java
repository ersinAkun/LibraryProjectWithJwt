package day34_inheritance;

public class Toyota {
    protected String marka ="Toyota";
    protected String model = "Model belirtilmedi";
    protected String yakit = "yakit belirtilmedi";

    protected void motor(){
        System.out.println("Toyota cevreci motorlar kullanir");
    }

    protected void aku (){
        System.out.println("Toyota modele gore aku kullanir");
    }







}
