package day06_concatenation;

public class C06_JavaVeriable {
    public static void main(String[] args) {

        int yas = 33;
        double boy = 1.70;
        System.out.println("yas  : " + yas);
        System.out.println("boy  :" + boy);


        int yasim = 33;
        int enesYas = yasim;
        System.out.println("enesYas = " + enesYas);
        System.out.println("yasim = " + yasim);

        int yıl = 2022, ay = 6, gün = 20;
        System.out.println("yıl = " + yıl);
        System.out.println("ay = " + ay);

        yıl = 2032;
        System.out.println("update yil :" + yıl);


        //


    }
}
