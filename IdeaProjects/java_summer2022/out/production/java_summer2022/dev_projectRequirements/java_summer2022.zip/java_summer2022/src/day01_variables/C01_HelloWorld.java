package day01_variables;

public class C01_HelloWorld {
  /*  public static void main(String[] args) {
        System.out.println("Hello world");

        StringBuilder sb = new StringBuilder(5 + 7 + "Java" + 4 + 5);

        String isim="Mesut";

        sb.append(isim, 2, 4);

        sb.delete(4, 6);

        System.out.println(sb);





    }*/


}



