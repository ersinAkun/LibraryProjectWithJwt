package day09_ternary;

public class C07_SwitchCaseBireysel {
    public static void main(String[] args) {


        String input = "";

        switch (input) {
            case "10":
                System.out.println("iki basamaklı en küçük sayi");
                break;
            case "100":
                System.out.println("üç basamakli en kücük sayi");
                break;
            case "1000":
                System.out.println("dört basamakli en kücük sayi");
                break;
            default :
                    System.out.println("geçerli bir sayi giriniz");
        }


    }


}

