package day25_constructor;

public class C04_Constructor {
    public static void main(String[] args) {

        C03 obj1 =  new C03();

        obj1.method01();
    }


}
