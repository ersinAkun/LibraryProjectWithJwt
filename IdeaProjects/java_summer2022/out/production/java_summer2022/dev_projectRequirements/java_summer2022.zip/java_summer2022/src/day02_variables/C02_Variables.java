package day02_variables;

public class C02_Variables {
    public static void main(String[] args) {
        int sayi = 10;
        char harf = 'A';
        boolean evliMi = true;
        System.out.println(sayi);
        System.out.println("Medeni Durumu :  "+ evliMi);
    //**************************************************
        String adiniz = "Oğuz";
        String soyadınız = "ATAY";
        System.out.println(adiniz);
        System.out.println(soyadınız);


    }
}
