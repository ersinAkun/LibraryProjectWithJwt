package day04_dataCasting;

public class C04_ExplicitNarrowing {
    public static void main(String[] args) {

        int sayi1 = 130;
        short sayi2 = (byte) sayi1;

        System.out.println(sayi2);
    }
}
