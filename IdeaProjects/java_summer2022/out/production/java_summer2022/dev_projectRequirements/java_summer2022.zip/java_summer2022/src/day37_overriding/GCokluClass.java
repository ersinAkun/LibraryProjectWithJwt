package day37_overriding;

public class GCokluClass {


}

class ikinciClass {
          /*
          intellij 'de actigimiz bir class icinde sadece bir public class bulunabilir
          Class sinirlri disinda public olmayan baska class larda olusturabiliriz
          ancak proje de yazdigimiz class ismini public yapmazsak
          proje ile class arasinda sorun olacagindan CTE olusur
           */

}