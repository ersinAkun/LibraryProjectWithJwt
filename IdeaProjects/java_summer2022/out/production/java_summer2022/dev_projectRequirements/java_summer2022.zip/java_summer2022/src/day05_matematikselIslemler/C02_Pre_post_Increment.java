package day05_matematikselIslemler;

public class C02_Pre_post_Increment {
    public static void main(String[] args) {

        int sayi =10;
        System.out.println("pre-increment  :  "+  ++sayi);


        System.out.println("post-increment  :  "+  sayi++);


        System.out.println("post-increment den sonra  :  "+ sayi);


    }
}
