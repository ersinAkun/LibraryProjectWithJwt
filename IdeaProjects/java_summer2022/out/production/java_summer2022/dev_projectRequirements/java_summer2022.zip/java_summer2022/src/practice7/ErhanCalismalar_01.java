package practice7;

import java.util.ArrayList;
import java.util.List;

public class ErhanCalismalar_01 {
    public static void main(String[] args) {
         /*
          elimizde urunlerin bulundugu bir liste var
          urun listesindeki istenen siradaki urunu
          istegimiz yeni urunle degistirip
           eski urunu, varolan eski urunler listesine ekleyelim
           orn: ikram yerine biskrem yapalim
         */
        List<String> urunler= new ArrayList<>();
        urunler.add("Nutella");
        urunler.add("Ikram");
        urunler.add("Cekirdek");
        urunler.add("Cay");

        for (int i = 0; i < args.length; i++) {


    }
}}
