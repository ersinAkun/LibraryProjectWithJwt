package day31_timeFormatter_varargs;

public class C06_StringBuilder {
    public static void main(String[] args) {

        StringBuilder strbld = new StringBuilder("Bugun burada");
    }
}